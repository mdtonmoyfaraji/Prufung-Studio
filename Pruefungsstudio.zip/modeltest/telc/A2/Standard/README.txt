Legen Sie hier die Moduldateien für telc A2 — Buch "Standard" ab:
  lesen.json
  hoeren.json
  schreiben.json
  sprechen.json
  bausteine.json  (nur telc)

Jede Datei ist genau das, was der Button "Einzelnes Modul" in
Prüfungsstudio → Import & Export erzeugt. Diese README.txt können Sie löschen,
sobald die echten JSON-Dateien hier liegen.

Weiteres Buch für dieses Niveau: legen Sie einen weiteren Ordner neben
"Standard" an (z. B. modeltest/telc/A2/Zusatzbuch/) und tragen Sie den
Ordnernamen zusätzlich in manifest.json ein.
